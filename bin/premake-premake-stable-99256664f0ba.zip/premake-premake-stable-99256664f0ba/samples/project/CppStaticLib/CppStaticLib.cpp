#include <stdio.h>

void CppStaticLib()
{
	printf("CppStaticLib\n");
}
