#include <stdio.h>

int main()
{
	printf("CppWindowedApp\n");
	return 0;
}
