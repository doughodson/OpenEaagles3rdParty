#include <stdio.h>

#define MY_SYMBOL
